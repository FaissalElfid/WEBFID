<?php

return [

    'verified' => 'Votre mail a été vérifié!',
    'invalid' => 'Le lien de vérification n\'est pas valide.',
    'already_verified' => 'L\'e-mail est déjà vérifié.',
    'user' => 'Nous ne pouvons pas trouver un utilisateur avec cette adresse e-mail.',
    'sent' => 'Nous avons envoyé votre lien de vérification par e-mail!',

];
