import './axios'
import './fontawesome'
import 'bootstrap'
import Vue from 'vue'
import { BootstrapVue } from 'bootstrap-vue'
Vue.use(BootstrapVue)
