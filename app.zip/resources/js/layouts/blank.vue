<template>
  <child />
</template>

<script>
export default {
  name: 'Blank'
}
</script>
